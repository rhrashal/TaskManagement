# TaskManagement

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.8.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
##=============================================================

##ngx-bootstrap =>
https://valor-software.com/ngx-bootstrap/#/documentation#getting-started

##toaster=>
https://www.npmjs.com/package/ngx-toastr

##Sweetalert=>
https://www.itsolutionstuff.com/post/how-to-use-sweetalert2-in-angularexample.html
https://sweetalert2.github.io/

##Block-Ui=>
https://www.npmjs.com/package/ng-block-ui

##Pagnation =>
https://jasonwatmore.com/post/2018/04/26/npm-jw-angular-pagination-component

##Filter => 
https://stackoverflow.com/questions/46780843/angular-4-filter-search-custom-pipe

https://www.ag-grid.com/angular-grid/getting-started/
https://www.codingnepalweb.com/