import { Component } from "@angular/core";


@Component({
  selector: 'notfound',
  template: '<h1>Page not found</h1>'
})
export class NotFoundComponent {
 

}